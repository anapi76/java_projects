package com.anapiqueras.api.exceptions;

public class ProductCantBeNullException extends Exception {
    public ProductCantBeNullException(String message) {
        super(message);
    }
}
