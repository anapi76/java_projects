package com.anapiqueras.api.exceptions;

public class TypeProductNotFoundException extends Exception {
    public TypeProductNotFoundException(String message) {
        super(message);
    }
}
