package com.anapiqueras.api.exceptions;

public class TypeProductCantBeNullException extends Exception {
    public TypeProductCantBeNullException(String message) {
        super(message);
    }
}
