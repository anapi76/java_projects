package com.anapiqueras.api.exceptions;

public class TypeProductCantBeDeletedException extends Exception {
    public TypeProductCantBeDeletedException(String message) {
        super(message);
    }
}

