INSERT INTO type_product (name) VALUES
    ('FOOD'),
    ('ELECTRONIC'),
    ('HYGIENIC');

INSERT INTO product (name, description, price, stock, type_product) VALUES
    ('Macarrones', 'Pasta con huevo', 1.39, 100,1),
    ('Ordenador', 'Ordenador portatil', 1000, 50,2),
    ('Desodorante', 'Desodorante mujer', 2.30, 60,3);

