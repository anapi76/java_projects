package com.anapiqueras.api;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.anapiqueras.api.dto.ProductDTO;
import com.anapiqueras.api.mapper.DTOMapperProduct;
import com.anapiqueras.api.persistence.model.ProductEntity;
import com.anapiqueras.api.persistence.model.TypeProduct;

public class DTOMapperProductTest {

    private DTOMapperProduct dtoMapperProduct = new DTOMapperProduct();

    @Test
    public void checkMapToProduct() {
        // Arrange
        ProductDTO productDto = new ProductDTO(1, "Macarrones", "Pasta con huevo", 1.39, 100, "FOOD");
        int idExpected = productDto.getIdProduct();
        String nameExpected = productDto.getName();
        String descriptionExpected = productDto.getDescription();
        Double priceExpected = productDto.getPrice();
        Integer stockExpected = productDto.getStock();
        TypeProduct typeExpected = TypeProduct.FOOD;
        // Act
        ProductEntity product = dtoMapperProduct.mapToProduct(productDto);
        int idActual = product.getIdProduct();
        String nameActual = product.getName();
        String descriptionActual = product.getDescription();
        Double priceActual = product.getPrice();
        Integer stockActual = product.getStock();
        TypeProduct typeActual = TypeProduct.FOOD;
        // Assert
        assertEquals(idExpected, idActual);
        assertEquals(nameExpected, nameActual);
        assertEquals(descriptionExpected, descriptionActual);
        assertEquals(priceExpected, priceActual);
        assertEquals(stockExpected, stockActual);
        assertEquals(typeExpected, typeActual);
    }
}
