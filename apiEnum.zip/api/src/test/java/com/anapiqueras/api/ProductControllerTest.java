package com.anapiqueras.api;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;

import com.anapiqueras.api.controller.ProductController;
import com.anapiqueras.api.domain.service.iProductService;
import com.anapiqueras.api.dto.ProductDTO;
import com.anapiqueras.api.exceptions.ProductCantBeNullException;
import com.anapiqueras.api.exceptions.ProductNotFoundException;

public class ProductControllerTest {
    @Mock
    private iProductService productService;

    @InjectMocks
    private ProductController productController = new ProductController(productService);

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    private ProductDTO product1 = new ProductDTO(1, "Macarrones", "Pasta con huevo", 1.39, 100, "FOOD");
    private ProductDTO product2 = new ProductDTO(2, "Tallarines", "Pasta con huevo", 1.39, 100, "FOOD");
    

    @Test
    public void checkIfThereAreProducts() {
        // Arrange
        List<ProductDTO> productList = List.of(product1, product2);
        // Act
        when(productService.findAll()).thenReturn(productList);
        HttpStatusCode code = productController.findAll().getStatusCode();
        // Assert
        assertEquals(HttpStatus.OK, code);
    }

    @Test
    public void checkIfThereAreAnyProducts() {
        // Arrange
        List<ProductDTO> productList = List.of();
        // Act
        when(productService.findAll()).thenReturn(productList);
        ResponseEntity<List<ProductDTO>> response = productController.findAll();
        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isEmpty());
    }

    @Test
    public void checkIfProductExist() throws ProductNotFoundException {
        // Arrange
        int idProduct = 1;
        // Act
        when(productService.findProductById(idProduct)).thenReturn(product1);
        HttpStatusCode code = productController.findProductById(idProduct).getStatusCode();
        // Assert
        assertEquals(HttpStatus.OK, code);
    }

    @Test
    public void checkIfProductNotExist() throws ProductNotFoundException {
        // Arrange
        int idProduct = 999;
        // Act
        when(productService.findProductById(idProduct)).thenThrow(ProductNotFoundException.class);
        HttpStatusCode result = productController.findProductById(idProduct).getStatusCode();
        // Assert
        assertEquals(HttpStatus.NOT_FOUND, result);
    }

    @Test
    public void checkCreateProduct() throws ProductCantBeNullException {
        // Arrange
    
        // Act
        when(productService.createProduct(product1)).thenReturn(product1);
        HttpStatusCode result = productController.createProduct(product1).getStatusCode();
        // Assert
        assertEquals(HttpStatus.CREATED, result);
    }

    @Test
    public void checkNotCreateProductIfIsNotValid() throws ProductCantBeNullException {
        // Arrange
        int idProduct = 1;
        ProductDTO product = new ProductDTO(idProduct, null, "Smartphone Samsung", 300.00, null, null);
        // Act
        when(productService.createProduct(product)).thenThrow(ProductCantBeNullException.class);
        HttpStatusCode result = productController.createProduct(product).getStatusCode();
        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, result);
    }

    @Test
    public void checkProductIsNull() {
        // Arrange

        // Act
        HttpStatusCode result = productController.createProduct(null).getStatusCode();
        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, result);
    }

    @Test
    public void checkUpdateProduct() throws ProductNotFoundException {
        // Arrange
        int idProduct = 1;
        ProductDTO product = new ProductDTO(idProduct, null, "Espirales", 0.0, null, null);
        ProductDTO productModified= new ProductDTO(1, "Espirales", "Pasta con huevo", 1.39, 100, "FOOD");
        // Act
        when(productService.updateProduct(idProduct, product)).thenReturn(productModified);
        HttpStatusCode result = productController.updateProduct(idProduct, product).getStatusCode();
        // Assert
        assertEquals(HttpStatus.CREATED, result);
    }

    @Test
    public void checkNotUpdateProduct() throws ProductNotFoundException {
        // Arrange
        int idProduct = 999;
        ProductDTO product = new ProductDTO(idProduct, null, "Smartphone Xiomi", null, 0, null);
        // Act
        when(productService.updateProduct(idProduct, product)).thenThrow(ProductNotFoundException.class);
        HttpStatusCode result = productController.updateProduct(idProduct, product).getStatusCode();
        // Assert
        assertEquals(HttpStatus.NOT_FOUND, result);
    }

    @Test
    public void checkDeleteProduct() throws ProductNotFoundException {
        // Arrange
        int idProduct = 2;
        // Act
        doNothing().when(productService).deleteProductById(idProduct);
        HttpStatusCode result = productController.deleteProductById(idProduct).getStatusCode();
        // Assert
        assertEquals(HttpStatus.OK, result);
    }

    @Test
    public void checkNotDeleteProduct() throws ProductNotFoundException {
        // Arrange
        int idProduct = 999;
        // Act
        doThrow(ProductNotFoundException.class).when(productService).deleteProductById(idProduct);
        HttpStatusCode result = productController.deleteProductById(idProduct).getStatusCode();
        // Assert
        assertEquals(HttpStatus.NOT_FOUND, result);
    }

}
