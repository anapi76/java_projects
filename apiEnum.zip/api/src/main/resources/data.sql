INSERT INTO product (name, description, price, stock, type) VALUES
    ('Macarrones', 'Pasta con huevo', 1.39, 100, 'FOOD'),
    ('Ordenador', 'Ordenador portatil', 1000, 50, 'ELECTRONIC'),
    ('Desodorante', 'Desodorante mujer', 2.30, 60, 'HYGIENIC');