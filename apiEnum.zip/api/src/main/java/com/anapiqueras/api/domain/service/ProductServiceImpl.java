package com.anapiqueras.api.domain.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.anapiqueras.api.domain.repository.iProductRepository;
import com.anapiqueras.api.dto.ProductDTO;

import com.anapiqueras.api.exceptions.ProductCantBeNullException;
import com.anapiqueras.api.exceptions.ProductNotFoundException;

@Service
public class ProductServiceImpl implements iProductService {

    public iProductRepository productRepository;

    public ProductServiceImpl(iProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @Override
    public List<ProductDTO> findAll() {
        List<ProductDTO> products = productRepository.findAll();
        return products;
    }

    @Override
    public ProductDTO findProductById(int id) throws ProductNotFoundException {
        ProductDTO productFound = productRepository.findProductById(id);
        return productFound;
    }

    @Override
    public ProductDTO createProduct(ProductDTO productDto) throws ProductCantBeNullException {
        if (productDto == null) {
            throw new ProductCantBeNullException("Product can't be null");
        }
        if (!validateProduct(productDto)) {
            return null;
        }
        ProductDTO createdProduct = productRepository.createProduct(productDto);

        return createdProduct;
    }

    @Override
    public ProductDTO updateProduct(int id, ProductDTO product) throws ProductNotFoundException {
        ProductDTO productFound = productRepository.findProductById(id);
        productFound.setIdProduct(id);
        if (product.getName() != null) {
            productFound.setName(product.getName());
        }
        if (product.getDescription() != null) {
            productFound.setDescription(product.getDescription());
        }
        if (product.getPrice() != null) {
            productFound.setPrice(product.getPrice());
        }
        if (product.getStock() != null) {
            productFound.setStock(product.getStock());
        }
        if (product.getType() != null) {
            productFound.setType(product.getType());
        }
        ProductDTO updatedProduct = productRepository.updateProduct(productFound);
        return updatedProduct;
    }

    @Override
    public void deleteProductById(int id) throws ProductNotFoundException {
        ProductDTO productFound=findProductById(id);
        productRepository.deleteProductById(id);
    }

    public Boolean validateProduct(ProductDTO product) {
        return (product.getName() != null && !product.getName().isEmpty() && product.getDescription() != null
                && !product.getDescription().isEmpty() && product.getPrice() != null && product.getPrice() > 0
                && product.getStock() != null && product.getStock() > 0 && product.getType() != null);
    }

}
