package com.anapiqueras.api.persistence.model;

public enum TypeProduct {
    FOOD, HYGIENIC, ELECTRONIC, type
}
