package com.anapiqueras.api.controller;

import java.util.List;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.anapiqueras.api.domain.service.iProductService;
import com.anapiqueras.api.dto.ProductDTO;
import com.anapiqueras.api.exceptions.ProductCantBeNullException;
import com.anapiqueras.api.exceptions.ProductNotFoundException;

@Controller
@RequestMapping("/product")
public class ProductController {

    /*
     * @Autowired
     * private iProductService productService;
     */
    public iProductService productService;

    public ProductController(iProductService productService) {
        this.productService = productService;
    }

 @GetMapping("/")
    public ResponseEntity<List<ProductDTO>> findAll() {
        List<ProductDTO> products = productService.findAll();
       if(products.isEmpty()){
        return new ResponseEntity<>(products,HttpStatus.OK);
       }    
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductDTO> findProductById(@PathVariable int id) {
        try {
            ProductDTO product = productService.findProductById(id);
            return new ResponseEntity<>(product, HttpStatus.OK);
        } catch (ProductNotFoundException pne) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/create")
    public ResponseEntity<ProductDTO> createProduct(@RequestBody ProductDTO product) {
        try {
            ProductDTO createdProduct = productService.createProduct(product);
            if (createdProduct == null) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            return new ResponseEntity<>(createdProduct, HttpStatus.CREATED);
        } catch (ProductCantBeNullException p) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<ProductDTO> updateProduct(@PathVariable int id, @RequestBody ProductDTO product) {
        try {
            ProductDTO productUpdated = productService.updateProduct(id, product);
            return new ResponseEntity<>(productUpdated, HttpStatus.CREATED);
        } catch (ProductNotFoundException pne) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteProductById(@PathVariable int id) {
        try {
            productService.deleteProductById(id);
            return new ResponseEntity<>("Product deleted:" + id, HttpStatus.OK);
        } catch (ProductNotFoundException pne) {
            return new ResponseEntity<>("Product not found for id: " + id,HttpStatus.NOT_FOUND);
        }
    }
}
