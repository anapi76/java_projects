package com.anapiqueras.api.mapper;

import org.springframework.stereotype.Component;

import com.anapiqueras.api.dto.ProductDTO;
import com.anapiqueras.api.persistence.model.ProductEntity;
import com.anapiqueras.api.persistence.model.TypeProduct;

@Component
public class DTOMapperProduct {

    public ProductEntity mapToProduct(ProductDTO productDto) {
        String type = productDto.getType();
        TypeProduct typeProduct = TypeProduct.valueOf(type);
        ProductEntity product = new ProductEntity(
                productDto.getName(),
                productDto.getDescription(),
                productDto.getPrice(),
                productDto.getStock(),
                typeProduct);
        product.setIdProduct(productDto.getIdProduct());
        return product;
    }
}
