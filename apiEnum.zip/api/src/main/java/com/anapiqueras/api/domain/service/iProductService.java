package com.anapiqueras.api.domain.service;

import java.util.List;

import com.anapiqueras.api.dto.ProductDTO;
import com.anapiqueras.api.exceptions.ProductCantBeNullException;
import com.anapiqueras.api.exceptions.ProductNotFoundException;

public interface iProductService {

    public List<ProductDTO> findAll();

    public ProductDTO findProductById(int id) throws ProductNotFoundException ;
    
    public ProductDTO createProduct(ProductDTO product) throws ProductCantBeNullException;

    public ProductDTO updateProduct(int id,ProductDTO product) throws ProductNotFoundException;

    public void deleteProductById(int id) throws ProductNotFoundException;

}
