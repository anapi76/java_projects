package com.anapiqueras.api.mapper;

import org.springframework.stereotype.Component;

import com.anapiqueras.api.dto.ProductDTO;
import com.anapiqueras.api.persistence.model.ProductEntity;


@Component
public class ProductMapperDTO {

    public ProductDTO mapToProductDto(ProductEntity product) {
        ProductDTO productDto = new ProductDTO(
                product.getIdProduct(),
                product.getName(),
                product.getDescription(),
                product.getPrice(),
                product.getStock(),
                product.getType().toString());
        return productDto;
    }
}
